import java.io.*;
import javax.swing.*;

/**
 * Class for simple input of text from file or standard input
 * 
 * @author Steve Townsend, incorporating ideas suggested by Gary Macindoe 
 * @author Jim Hunter
 * @version 22 Oct 2004
 */
public class TextReader extends TextFileHandler{

    private BufferedReader reader;
    // reader for buffered input
    private boolean stdio;
    // true if input is System.in
    private boolean open;
    // true if reader is successfully opened
 
    /**
     * Open standard input
     */
    public TextReader() 
    {
        stdio = true;
        try{
            //open new buffered reader for standard input
            reader = new BufferedReader(new InputStreamReader(System.in));
            open = true;
        }
        catch (Exception e) {
            System.err.println("Exception raised in TextReader() : "+e);
            open = false;
        }
     }
    
    /**
     * Opens a file using a file name. If file name is an empty string, or if
     * the file does not exist then invites user to provide file name via a dialog box.
     * @param fileName the file name
     */
    public TextReader(String fileName) 
    {
        stdio = false;
        File file = null;
        if ((fileName != null) && !fileName.equals("")) 
            file = makeAbsoluteFilename(fileName);
        // open new buffered reader for the specified file
        try {
            reader = new BufferedReader(new FileReader(file));
            open = true;
        }
        catch (Exception e) { // if unsuccessful use a file chooser
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Choose text file to read from");
            fc.setApproveButtonText("Read from file");
            fc.setApproveButtonToolTipText("Click to confirm choice of file");
            int response = fc.showDialog(null,null); // prompt user for filename
            if (response == JFileChooser.APPROVE_OPTION) { // response ok
                file = fc.getSelectedFile();
                try{
                    reader = new BufferedReader(new FileReader(file));
                    open = true;
                }
                catch (FileNotFoundException e1) { // file still not avaliable
                    System.err.println("IOException" +e1+ "raised in TextReader("+fileName+")");
                    open = false;
                }
            }
            else { // no response on selecting file
                 System.err.println("No file selected in TextReader("+fileName+")");
                 open = false;
            }
        }
    }

     /**
     * Reads a complete line
     * @return  the remainder of the line as a string,
     *          null if the end-of-file is reached
     *          null if an I/O exception is raised
     */
    public String readLine()
    {
        if (open){
            try{
                return reader.readLine();
            } 
            catch (IOException e) {
                System.err.println("IOException raised in readLine(): " +e);
                return null;
            }
        }
        else {
            System.err.println("File is not open in readLine()");
            return null;
        }       
    }

   /**
     * Reads a single character
     * @return  the next character in the file as an integer,
     *          -1 if end-of-file is reached
     *          -2 if an I/O exception is raised
     */
    public int readChar()  
    {
        if (open){
            try{
                return reader.read();
            }
            catch (IOException e) {
                System.err.println("IOException raised in readChar(): " +e);
                return -2;
            } 
        }
        else {
            System.err.println("File is not open in readChar()");
            return -2;
        }
    }
    
    /**
     * Closes a file
     */
    public void close()
    {
        if (open){
            try
            {
                reader.close();
            } 
            catch (IOException e){
                System.err.println("IOException raised in close(): "+e);
            }
        }
    }

}