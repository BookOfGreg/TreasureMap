import java.io.*;
import javax.swing.*;

/**
 * Class for simple input of text from file or standard input
 * 
 * @author Steve Townsend, incorporating ideas suggested by Gary Macindoe 
 * @author Jim Hunter
 * @version 22 October 2004
 */
public class TextWriter extends TextFileHandler{

    private BufferedWriter writer;
    // reader for buffered input
    private boolean stdio;
    // true if output is System.out
    private boolean open;
    // true if writer is successfully opened
 
    /**
     * Open standard output
     */
    public TextWriter() 
    {
        stdio = true;
        open = true;
    }
    
    /**
     * Opens a file using a file name. If file name is an empty string
     * then invites user to provide file name via a dialog box.
     * @param fileName the file name
     */
    public TextWriter(String fileName) 
    {
        stdio = false;
        File file = null;
        if ((fileName != null) && !fileName.equals("")) 
            file = makeAbsoluteFilename(fileName);
        // open new buffered writer for the specified file
        try {
            writer = new BufferedWriter(new FileWriter(file));
            open = true;
        }
        catch (Exception e) { // if unsuccessful use a file chooser
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Choose text file to write to");
            fc.setApproveButtonText("Write to file");
            fc.setApproveButtonToolTipText("Click to confirm choice of file");
            int response = fc.showDialog(null,null); // prompt user for filename
            if (response == JFileChooser.APPROVE_OPTION) { // response ok
                file = fc.getSelectedFile();
                try{
                    writer = new BufferedWriter(new FileWriter(file));
                    open = true;
                }
                catch (IOException e1) { // file still not avaliable
                    System.err.println("IOException" +e1+ "raised in TextWriter("+fileName+")");
                    open = false;
                }
            }
            else { // no response on selecting file
                 System.err.println("No file selected in TextWriter("+fileName+")");
                 open = false;
            }
        }
    }

    /**
     * Write a string followed by a newline
     * @param s  the String to be written
     */
    public void writeLine(String s)  
    {
        if (open){
            try{
                if (stdio)
                   System.out.println(s);
                else {
                    writer.write(s);
                    writer.newLine();
                }
            }
            catch (IOException e) {
                System.out.println("IOException raised in writeLine("+s+"): "+e);
            }         
        }
        else {
            System.err.println("File is not open in writeLine("+s+")");
        }
    }
    
    /**
     * Write a newline
     */
    public void writeLine() 
    {
        if (open){
            try{
                if (stdio)
                    System.out.println();
                else
                    writer.newLine();
            }
            catch (IOException e) {
                System.out.println("IOException" +e+ "raised in writeLine");
            }         
        }
        else {
            System.err.println("File is not open in writeLine()");
        }
    }
   /**
     * Write a single character
     * @param c  int representing the character to be written
     */
    public void writeChar(int c) 
    {
        if (open){
            try{
                if (c >= 0) {
                    if (stdio)
                        System.out.print((char)c);
                    else
                        writer.write(c);
                }
            }
            catch (IOException e) {
                System.out.println("IOException raised in writeChar("+(char) c+"): "+e);
            }
        }
        else {
            System.err.println("File is not open in readChar()");
        }
    }
        
    /**
     * Write a String
     * @param s  the String to be written
     */
    public void writeString(String s) 
    {
        if (open){
            try{
                if (stdio)
                    System.out.print(s);
                else
                    writer.write(s);
            }
            catch (IOException e) {
                System.out.println("IOException raised in writeString("+s+"): "+e);
            }         
        }
        else {
            System.err.println("File is not open in writeString("+s+")");
        }
    }

    
    /**
     * Closes a file
     */
    public void close()
    {
        if (open){
            try
            {
                writer.close();
            } 
            catch (IOException e){
                System.err.println("IOException raised in close(): "+e);
            }
        }
    }


}