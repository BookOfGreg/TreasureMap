import java.io.*;

/**
 * Abstract class TextFileHandler - provides services for TextReader and TextWriter
 * 
 * @author Jim Hunter
 * @version 19th April 2004
 */
public abstract class TextFileHandler
{

    /**
     * Create an absolute file from the given file name.
     * If the filename is an absolute one already, then use it
     * unchanged, otherwise assume it is relative to the
     * current project folder.
     */
    protected File makeAbsoluteFilename(String filename)
    {
        File file = new File(filename);
        if(!file.isAbsolute()) {
            file = new File(getProjectFolder(), filename);
        }
        return file;
    }
    
    /**
     * Try to determine the name of the current project folder,
     * defiuned as the folder that contains this class file.
     * @return The name of the current project folder.
     */
    private String getProjectFolder()
    {
        String parentDir = null;
        try {                      // try to get class directory
            parentDir = getClass().getResource(".").getFile();
        } catch (Exception e) { } // ignore any exception
        return parentDir;
    }
}
